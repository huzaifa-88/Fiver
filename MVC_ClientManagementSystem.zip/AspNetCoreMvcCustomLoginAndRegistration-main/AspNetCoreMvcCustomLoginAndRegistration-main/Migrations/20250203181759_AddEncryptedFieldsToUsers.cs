﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UsersApp.Migrations
{
    /// <inheritdoc />
    public partial class AddEncryptedFieldsToUsers : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "FullName",
                table: "AspNetUsers",
                newName: "EncryptedNormalizedEmail");

            migrationBuilder.AddColumn<string>(
                name: "EncryptedEmail",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EncryptedFullName",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EncryptedEmail",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "EncryptedFullName",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "EncryptedNormalizedEmail",
                table: "AspNetUsers",
                newName: "FullName");
        }
    }
}
