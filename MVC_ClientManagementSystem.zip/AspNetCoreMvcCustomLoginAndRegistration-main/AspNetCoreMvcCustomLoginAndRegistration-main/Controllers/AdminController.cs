﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UsersApp.Data;
using UsersApp.Models;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using UsersApp.Helper;

namespace UsersApp.Controllers
{
    [Authorize(Roles = "Admin")]
    [Route("Admin")]
    public class AdminController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<Users> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AdminController(AppDbContext context, UserManager<Users> userManager, RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }
        [HttpGet("Dashboard")]
        public IActionResult Dashboard()
        {
            return View();
        }

        [HttpGet("ManageRoles")]

        public async Task<IActionResult> ManageRoles()
        {

            var users = await _context.Users.ToListAsync();
            var roles = await _roleManager.Roles.ToListAsync();

            // Decrypt user emails before passing to the view
            foreach (var user in users)
            {
                user.Email = EncryptionHelper.Decrypt(user.EncryptedEmail);
                user.FullName = EncryptionHelper.Decrypt(user.EncryptedFullName);
            }

            // Setting users and roles in ViewBag
            ViewBag.Users = users;
            ViewBag.Roles = roles;
            return View(roles);

        }
        [HttpGet("Logs")]
        public IActionResult Logs()
        {
            return View();
        }
        [HttpGet("Settings")]
        public IActionResult Settings()
        {
            return View();
        }

        // ========== CRUD for Clients ==========

        [HttpGet("Clients")]
        public async Task<IActionResult> Clients()
        {
            var clients = await _userManager.GetUsersInRoleAsync("Client");
            foreach (var client in clients)
            {
                client.Email = EncryptionHelper.Decrypt(client.EncryptedEmail);
                client.FullName = EncryptionHelper.Decrypt(client.EncryptedFullName);
            }
            return View(clients);
        }

        [HttpGet("CreateClient")]
        public IActionResult CreateClient()
        {
            return View();
        }

        [HttpPost("CreateClient")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateClient(Users user)
        {
            if (ModelState.IsValid)
            {
                user.UserName = user.Email;
                user.EncryptedEmail = EncryptionHelper.Encrypt(user.Email);
                user.EncryptedFullName = EncryptionHelper.Encrypt(user.FullName);
                var result = await _userManager.CreateAsync(user, "Client@123"); // Default password

                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(user, "Client");
                    return RedirectToAction("Clients");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(user);
        }

        [HttpGet("EditClient")]
        public async Task<IActionResult> EditClient(String id)
        {
            var client = await _context.Users.FindAsync(id);
            if (client == null) return NotFound();
            // Decrypt the data before showing it
            client.Email = EncryptionHelper.Decrypt(client.EncryptedEmail);
            client.FullName = EncryptionHelper.Decrypt(client.EncryptedFullName);
            return View(client);
        }

        [HttpPost("EditClient")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditClient(String id, Users client)
        {
            if (ModelState.IsValid)
            {
                var existingClient = await _context.Users.FindAsync(id);
                if (existingClient == null) return NotFound();

                // Encrypt before saving
                existingClient.EncryptedEmail = EncryptionHelper.Encrypt(client.Email);
                existingClient.EncryptedFullName = EncryptionHelper.Encrypt(client.FullName);

                _context.Users.Update(existingClient);
                await _context.SaveChangesAsync();
                return RedirectToAction("Clients");
            }

            return View(client);
        }

        // Delete Client (GET)
        [HttpGet("DeleteClient")]
        public async Task<IActionResult> DeleteClient(String id)
        {
            var client = await _context.Users.FindAsync(id);
            if (client == null) return NotFound();
            return View(client);
        }

        // Delete Client (POST)
        [HttpPost, ActionName("DeleteConfirmation")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmDeleteClient(String id)
        {
            var client = await _context.Users.FindAsync(id);
            if (client != null)
            {
                _context.Users.Remove(client);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Clients");
        }

        // ==========CRUD for Manage Roles=============

        [HttpPost("CreateRole")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateRole(string roleName)
        {
            if (!string.IsNullOrWhiteSpace(roleName))
            {
                var roleExists = await _roleManager.RoleExistsAsync(roleName);
                if (!roleExists)
                {
                    var identityRole = new IdentityRole(roleName); // ✅ Ensure correct type usage
                    var result = await _roleManager.CreateAsync(identityRole);

                    if (!result.Succeeded)
                    {
                        ModelState.AddModelError("", "Failed to create role.");
                    }
                }
            }
            return RedirectToAction("ManageRoles");
        }
        [HttpPost("DeleteRole")]
        public async Task<IActionResult> DeleteRole(string roleId)
        {
            var role = await _roleManager.FindByIdAsync(roleId);
            if (role != null)
            {
                await _roleManager.DeleteAsync(role);
            }
            return RedirectToAction("ManageRoles");
        }

        // Assign a role to a user
        [HttpPost("AssignRole")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignRole(string userId, string roleName)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user != null && !string.IsNullOrEmpty(roleName))
            {
                await _userManager.AddToRoleAsync(user, roleName);
            }
            return RedirectToAction("ManageRoles");
        }

        // Remove a user from a role
        [HttpPost("RemoveUserRole")]
        public async Task<IActionResult> RemoveUserRole(string userId, string roleName)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user != null)
            {
                await _userManager.RemoveFromRoleAsync(user, roleName);
            }
            return RedirectToAction("ManageRoles");
        }
    }
}
