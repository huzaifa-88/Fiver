﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UsersApp.Models;
using UsersApp.Data;
using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using UsersApp.ViewModels;

namespace UsersApp.Controllers
{
    [Authorize(Roles = "Client")] // Ensure only clients can access
    public class ClientController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<Users> _userManager;

        public ClientController(AppDbContext context, UserManager<Users> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        [HttpGet]
        public IActionResult Profile()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);

            if (user == null)
                return NotFound();

            var model = new RegisterViewModel
            {
                Name = user.FullName,
                Email = user.Email,
            };

            return View(model);
        }

        [HttpGet]
        public IActionResult EditProfile()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);

            if (user == null)
                return NotFound();

            var model = new RegisterViewModel
            {
                Name = user.FullName,
                Email = user.Email,
            };


            return View(model);
        }

        [HttpPost]
        public IActionResult EditProfile(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = _context.Users.FirstOrDefault(u => u.Id == userId);

            if (user == null)
                return NotFound();

            user.FullName = model.Name;

            _context.SaveChanges();

            return RedirectToAction("Profile");
        }
    }
}
