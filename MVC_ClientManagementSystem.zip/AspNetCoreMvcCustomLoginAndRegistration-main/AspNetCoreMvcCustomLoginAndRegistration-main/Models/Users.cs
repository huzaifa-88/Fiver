﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using UsersApp.Helper;

namespace UsersApp.Models
{
    public class Users : IdentityUser
    {
        [Required]
        public string EncryptedFullName { get; set; } // Encrypted in DB

        [NotMapped]
        public string FullName
        {
            get => string.IsNullOrEmpty(EncryptedFullName) ? "" : EncryptionHelper.Decrypt(EncryptedFullName);
            set => EncryptedFullName = EncryptionHelper.Encrypt(value);
        }

        [Required]
        public string EncryptedEmail { get; set; } // Encrypted Email

        [NotMapped]
        public string DecryptedEmail
        {
            get => string.IsNullOrEmpty(EncryptedEmail) ? "" : EncryptionHelper.Decrypt(EncryptedEmail);
            set => EncryptedEmail = EncryptionHelper.Encrypt(value);
        }

        public string EncryptedNormalizedEmail { get; set; } // Encrypted Normalized Email

        public void SetEmail(string email)
        {
            if (!string.IsNullOrEmpty(email))
            {
                EncryptedEmail = EncryptionHelper.Encrypt(email);
                Email = email; // Set ASP.NET Identity Email
                EncryptedNormalizedEmail = EncryptionHelper.Encrypt(email.ToUpper());
                NormalizedEmail = email.ToUpper(); // Keep it for Identity
            }
        }
    }
}