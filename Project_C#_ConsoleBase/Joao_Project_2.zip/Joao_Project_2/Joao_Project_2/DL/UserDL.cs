﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Joao_Project_2.BL;
using Joao_Project_2.Classes;


namespace Joao_Project_2.DL
{
    internal class UserDL
    {
        public static List<UserBL> userlist = new List<UserBL>();
        public static Dictionary<string, List<WalletBL>> UserWallets = new Dictionary<string, List<WalletBL>>();

        // User Registeration Method
        public static bool UserRegister()
        {
            string username; 
            string password;
            string email;
            bool isReg = false;
            Console.Write("Enter Valid Email:");
            email = Console.ReadLine();
            if (userlist.Exists(user => user.Email == email))
            {
                Console.WriteLine("Error: This Email is already registered. Please try another one");
                return isReg;
            }
            if (!UserBL.IsValidEmail(email))
            {
                Console.WriteLine("Error: Email is not in the correct format.");
                return isReg;
            }

            Console.Write("Enter UserName:");
            username = Console.ReadLine();
            if (userlist.Exists(user => user.Username == username)) {
                Console.WriteLine("Error: This UserName is already taken. Please try another one");
                return isReg;
            }
            Console.Write("Enter Password:");
            password = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Console.WriteLine("Error: Username or Password cannot be null or empty.");
                return isReg;
            }
            string hashedPassword = UserBL.HashPassword(password);
            isReg = true;
            userlist.Add(new UserBL(username, hashedPassword, email));

            UserWallets[username] = new List<WalletBL>();
            return isReg;
        }

        // User Login Method
        public static bool userLogin(string username, string password) {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Console.WriteLine("Username or Password cannot be empty!");
                return false;
            }

            string hashPassword = UserBL.HashPassword(password);

            foreach (var user in userlist)
            {
                if (user.Username == username && user.Password == hashPassword)
                {
                    // Login successful
                    Session.CurrentUser = user; // Set the current logged-in user
                    Console.WriteLine($"Welcome, {username}!");
                    return true;
                }
            }

            return false;
        }

        public static List<WalletBL> GetCurrentUserWallets()
        {
            if (Session.CurrentUser == null)
            {
                Console.WriteLine("Error: No user is currently logged in.");
                return new List<WalletBL>();
            }

            if (UserWallets.ContainsKey(Session.CurrentUser.Username))
            {
                return UserWallets[Session.CurrentUser.Username];
            }

            Console.WriteLine("Error: No wallets available for the current user.");
            return new List<WalletBL>();
        }
    }
}
