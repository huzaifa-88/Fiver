﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Joao_Project_2.BL;
using Joao_Project_2.Classes;

namespace Joao_Project_2.DL
{
    internal class WalletDL
    {
        public static List<WalletBL> walletlist = new List<WalletBL>();

        public static WalletBL createWallet()
        {
            Currency currencyName;
            if (Session.CurrentUser == null)
            {
                Console.WriteLine("No user is currently logged in.");
                return null;
            }
            string walletName;
            string currencyInput;
            double amount;
            // Wallet name validation
            do
            {
                Console.Write("Wallet Name: ");
                walletName = Console.ReadLine();

                // Check if the wallet name already exists for the current user
                if (UserDL.UserWallets[Session.CurrentUser.Username].Any(wallet => wallet.WalletName.Equals(walletName, StringComparison.OrdinalIgnoreCase)))
                {
                    Console.WriteLine("A wallet with this name already exists. Please choose a different name.");
                }
                else
                {
                    break; // Exit loop if wallet name is unique
                }
            } while (true);
            do
            {
                Console.Write("Currency Name (Rub, Eur, Usd): ");
                currencyInput = Console.ReadLine();

                if (Enum.TryParse(currencyInput, true, out currencyName))
                {
                    if (UserDL.UserWallets[Session.CurrentUser.Username].Any(wallet => wallet.CurrencyName == currencyName))
                    {
                        Console.WriteLine($"A wallet for the currency {currencyName} already exists. Please choose a different currency.");
                    }
                    else
                    {
                        break; // Exit the loop if valid currency is provided and no wallet exists for it
                    }
                }
                else
                {
                    Console.WriteLine("Invalid currency. Please enter Rub, Eur, or Usd.");
                }
            } while (true);
            Console.Write("Start Amount: ");
            amount = double.Parse(Console.ReadLine());
            if (amount <= 0) throw new ArgumentException("Amount Must be greater than 0");
            //Console.WriteLine(walletName + " " + currencyName + " " + amount);
            WalletBL walletBL = new WalletBL(walletName, currencyName, amount);
            if (!UserDL.UserWallets.ContainsKey(Session.CurrentUser.Username))
            {
                UserDL.UserWallets[Session.CurrentUser.Username] = new List<WalletBL>();
            }
            UserDL.UserWallets[Session.CurrentUser.Username].Add(walletBL);

            Console.WriteLine($"Wallet '{walletBL.WalletName}' created successfully for user {Session.CurrentUser.Username}.");
            return walletBL;
            return walletBL;
        }
    }
}
