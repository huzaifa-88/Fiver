﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Joao_Project_2.Classes;
using Joao_Project_2.DL;
using Joao_Project_2.UI;

namespace Joao_Project_2.BL
{
    public class WalletBL
    {
        private string walletName;
        private Currency currencyName;
        public Money Balance { get; private set; }
        private List<Operation> operations { get;  set; }
        public bool IsActive { get; set; }

        WalletDL walletDL;

        public WalletBL(string walletName, Currency currencyName, double startAmount)
        {
            WalletName = walletName;
            CurrencyName = currencyName;
            Balance = new Money(startAmount, currencyName);
            operations = new List<Operation>();
            IsActive = false;
        }

        public WalletBL() { }
        

        public void AddOperation(Operation operation)
        {
            Console.WriteLine();
            if(operation.Amount.Currency != CurrencyName)
            {
                Console.WriteLine("Currency Mismatch");
                return;
            }

            if (operation is Income income)
            {
                Balance.Add(income.Amount.Value);
                operations.Add(income);
                Console.WriteLine($"Income added: {income.Amount.Value}. New balance: {Balance.Value}");
            }
            else if(operation is Expense expense)
            {
                if (Balance.Subtract(expense.Amount.Value))
                {
                    operations.Add(expense);
                    Console.WriteLine($"Expense deducted: {expense.Amount.Value}. New balance: {Balance.Value}");
                }
                else
                {
                    Console.WriteLine("Insufficient Balance");
                }
            }
        }

        public void CollectStatistics(DateTime from, DateTime to)
        {
            var filteredOperations = operations.FindAll(op => op.Date1 >= from && op.Date1 <= to);

            Console.WriteLine("\n--- Operations Summary ---");
            if (filteredOperations.Count == 0)
            {
                Console.WriteLine("No operations found in the specified date range.");
                return;
            }

            foreach (var op in filteredOperations)
            {
                string type = op is Income ? "Income" : "Expense";
                Console.WriteLine($"{type}: {op.Amount.Value} {op.Amount.Currency}, Date: {op.Date1}");
            }
        }

        public double ViewBalance()
        {
            return Balance.Value;
        }

        public WalletBL ActivateWallet(List<WalletBL> walletList)
        {
            int walletNo;
            WalletBL selectedWallet = null;

            // Ensure we are dealing with the current user's wallets only
            if (walletList.Count == 0)
            {
                Console.WriteLine("No wallets available for activation.");
                return null;
            }

            // Display available wallets for the current user
            while (true)
            {
                Console.WriteLine("\nAvailable Wallets:");
                for (int i = 0; i < walletList.Count; i++)
                {
                    var wallet = walletList[i];
                    Console.WriteLine($"{i + 1}. {wallet.WalletName} ({wallet.CurrencyName})" + (wallet.IsActive ? " [Active]" : ""));
                }

                // Prompt the user to enter a wallet number
                Console.Write("Enter wallet number to activate: ");
                bool isValidInput = int.TryParse(Console.ReadLine(), out walletNo);

                // Validate the wallet number input
                if (!isValidInput || walletNo <= 0 || walletNo > walletList.Count)
                {
                    Console.WriteLine("Invalid wallet number. Please enter a valid number.");
                    continue; // Continue the loop if input is invalid
                }

                // Find the selected wallet
                selectedWallet = walletList[walletNo - 1]; // 1-based index correction

                // Deactivate all wallets
                foreach (var wallet in walletList)
                {
                    wallet.IsActive = false;
                }

                // Activate the selected wallet
                selectedWallet.IsActive = true;
                Console.WriteLine($"Wallet '{selectedWallet.WalletName}' is now the active wallet.");
                break; // Exit the loop once the wallet is activated
            }

            // Return the selected active wallet
            return selectedWallet;
        }
        public void getAllWallets()
        {
            if (Session.CurrentUser == null)
            {
                Console.WriteLine("No user is currently logged in.");
                return;
            }
            var wallets = UserDL.GetCurrentUserWallets();
            if (wallets.Count == 0)
            {
                Console.WriteLine("No wallets available for the current user.");
                return;
            }

            Console.WriteLine($"\nAvailable Wallets for {Session.CurrentUser.Username}:");
            for (int i = 0; i < wallets.Count; i++)
            {
                var wallet = wallets[i];
                Console.WriteLine($"{i + 1}. {wallet.WalletName} ({wallet.CurrencyName})" + (wallet.IsActive ? " [Active]" : ""));
            }
        }

        public static void active_wallet_Operations(WalletBL activeWallet)
        {
            int choice;
            bool userOption = true;
            if (activeWallet == null)
            {
                Console.WriteLine("No active wallet selected.");
                return;
            }
            while (userOption)
            {
                Console.WriteLine("1. Add Income");
                Console.WriteLine("2. Add Expense");
                Console.WriteLine("3. View Wallet Balance");
                Console.WriteLine("4. View Statistics (by Date Range)");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        //Add Income
                        AddIncomeOperation(activeWallet);
                        break;
                    case 2:
                        //Add expense
                        AddExpenseOperation(activeWallet);
                        break;
                    case 3:
                        Console.WriteLine($"Your Balance: {activeWallet.ViewBalance()} {activeWallet.CurrencyName}");
                        break;
                    case 4:
                        //view statistics
                        ViewStatistics(activeWallet);
                        break;
                    case 5:
                        Console.WriteLine("Exiting Wallet operations");
                        UserUI.ClearScreen();
                        userOption = false;
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

            }
        }

        // Helper methods for operations
        private static void AddIncomeOperation(WalletBL activeWallet)
        {
            Console.Write("Enter income amount: ");
            if (double.TryParse(Console.ReadLine(), out double incomeAmount) && incomeAmount > 0)
            {
                IncomeType incomeType;
                while (true)
                {
                    Console.Write("Enter income type (Salary, Scholarship, Other): ");
                    if (Enum.TryParse(Console.ReadLine(), true, out incomeType) && Enum.IsDefined(typeof(IncomeType), incomeType))
                    {
                        activeWallet.AddOperation(new Income(DateTime.Now, new Money(incomeAmount, activeWallet.CurrencyName), incomeType));
                        break;
                    }
                    Console.WriteLine("Invalid income type. Please try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid amount. Please enter a value greater than 0.");
            }
        }

        private static void AddExpenseOperation(WalletBL activeWallet)
        {
            Console.Write("Enter expense amount: ");
            if (double.TryParse(Console.ReadLine(), out double expenseAmount) && expenseAmount > 0)
            {
                ExpenseType expenseType;
                while (true)
                {
                    Console.Write("Enter expense type (Food, Restaurants, Medicine, etc.): ");
                    if (Enum.TryParse(Console.ReadLine(), true, out expenseType) && Enum.IsDefined(typeof(ExpenseType), expenseType))
                    {
                        activeWallet.AddOperation(new Expense(DateTime.Now, new Money(expenseAmount, activeWallet.CurrencyName), expenseType));
                        break;
                    }
                    Console.WriteLine("Invalid expense type. Please try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid amount. Please enter a value greater than 0.");
            }
        }

        private static void ViewStatistics(WalletBL activeWallet)
        {
            Console.Write("Enter start date (yyyy-mm-dd): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime startDate))
            {
                Console.Write("Enter end date (yyyy-mm-dd): ");
                if (DateTime.TryParse(Console.ReadLine(), out DateTime endDate))
                {
                    activeWallet.CollectStatistics(startDate, endDate);
                }
                else
                {
                    Console.WriteLine("Invalid end date.");
                }
            }
            else
            {
                Console.WriteLine("Invalid start date.");
            }
        }
        public string WalletName { get => walletName; set => walletName = value; }
        public Currency CurrencyName { get => currencyName; set => currencyName = value; }
    }
}
