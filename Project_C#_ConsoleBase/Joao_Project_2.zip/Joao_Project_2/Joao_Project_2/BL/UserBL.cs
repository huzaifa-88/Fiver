﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Joao_Project_2.BL
{
    public class UserBL
    {
        private string username;
        private string hashed_password;
        private string email;

        public UserBL(string username, string password, string email)
        {
            this.username = username;
            this.hashed_password = password;
            this.email = email;
        }

        public string Username { get => username; set => username = value; }
        public string Password { get => hashed_password; set => hashed_password = value; }
        public string Email { get => email; set => email = value; }


        //Hashing Password method
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Convert the input password to a byte array
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);

                // Compute the hash
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                // Convert the hash bytes to a hexadecimal string
                StringBuilder hashString = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    hashString.Append(b.ToString("x2")); // Convert each byte to hex
                }

                return hashString.ToString();
            }
        }
        public static bool IsValidEmail(string email)
        {
            // Regular expression for validating email
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
    }
}
