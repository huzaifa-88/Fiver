﻿using System;
using Joao_Project_2.BL;
using Joao_Project_2.Classes;
using Joao_Project_2.DL;
using Joao_Project_2.UI;


namespace Joao_Project_2
{
    public enum Currency
    {
        Rub,
        Eur,
        Usd
    }

    public enum IncomeType
    {
        Salary,
        Scholarship,
        Other
    }

    public enum ExpenseType
    {
        Food,
        Restaurants,
        Medicine,
        Sport,
        Taxi,
        Rent,
        Investments,
        Clothes,
        Fun,
        Other
    }
    class Program
    {
        static void Main(string[] args)
        {
            UserBL credentials;
            WalletBL wallet = new WalletBL();
            int option;
            bool isUser;
            bool isWalletCreated;
            while (true)
            {
                try
                {
                    option = UserUI.userMenu();
                    //Regsiter Option---------------
                    if (option == 1)
                    {
                        isUser = UserDL.UserRegister();
                        if (isUser)
                        {
                            Console.WriteLine("User Successfully Register");
                            UserUI.ClearScreen();
                        }
                        else
                        {
                            UserUI.ClearScreen();
                        }
                    }
                    //Login Option-----------------
                    else if (option == 2)
                    {
                        Console.Write("Enter UserName:");
                        string username = Console.ReadLine();
                        Console.Write("Enter Password:");
                        string password = Console.ReadLine();
                        isUser = UserDL.userLogin(username, password);
                        if (isUser)
                        {
                            Console.WriteLine("User Successfully Login");
                            UserUI.ClearScreen();
                            bool menu = true;
                            while (menu)
                            {
                                try
                                {
                                    option = UserUI.MainMenu();
                                    switch (option)
                                    {
                                        case 1:
                                            //Create Wallet
                                            wallet = WalletDL.createWallet();
                                            UserUI.ClearScreen();
                                            break;
                                        case 2:
                                            //Activate Wallet
                                            var currentUserWallets = UserDL.GetCurrentUserWallets();
                                            if (currentUserWallets.Count > 0)
                                            {
                                                // Display all wallets and let the user activate one
                                                WalletBL activeWallet = wallet.ActivateWallet(currentUserWallets);

                                                if (activeWallet != null)
                                                {
                                                    Console.WriteLine($"Currently active wallet: {activeWallet.WalletName} ({activeWallet.CurrencyName})");
                                                    UserUI.ClearScreen();
                                                    WalletBL.active_wallet_Operations(activeWallet);
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("No wallets available for the current user.");
                                            }
                                            UserUI.ClearScreen();
                                            break;
                                        case 3:
                                            //View All Wallets
                                            wallet.getAllWallets();
                                            UserUI.ClearScreen();
                                            break;
                                        case 4:
                                            Console.WriteLine("User Logging out");
                                            UserUI.ClearScreen();
                                            menu = false;
                                            break;
                                        default:
                                            Console.WriteLine("Wrong Input");
                                            UserUI.ClearScreen();
                                            break;
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    UserUI.ClearScreen();
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Unauthorized User");
                            UserUI.ClearScreen();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: Wrong Input");
                        UserUI.ClearScreen();
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                    UserUI.ClearScreen();
                }
            }
        }
    }
}