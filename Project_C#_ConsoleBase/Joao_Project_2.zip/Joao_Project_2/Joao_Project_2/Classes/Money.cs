﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joao_Project_2.Classes
{
    public class Money
    {
        private double value;
        private Currency currency;

        public Money(double value, Currency currency)
        {
            Value = value;
            Currency = currency;
        }
        public Money() { }

        public void Add(double amount)
        {
            Value += amount;
        }
        public bool Subtract(double amount)
        {
            if (amount > Value)
            {
                return false; // Insufficient balance
            }
            Value -= amount;
            return true;
        }

        public double Value { get => value; set => this.value = value; }
        public Currency Currency { get => currency; set => currency = value; }
    }
}
