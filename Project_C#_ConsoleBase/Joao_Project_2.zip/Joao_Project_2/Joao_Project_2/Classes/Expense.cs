﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joao_Project_2.Classes
{
    public class Expense : Operation
    {
        public ExpenseType Type { get; set; }

        public Expense(DateTime date, Money amount, ExpenseType type) : base(date, amount)
        {
            Type = type;
        }
    }
}
