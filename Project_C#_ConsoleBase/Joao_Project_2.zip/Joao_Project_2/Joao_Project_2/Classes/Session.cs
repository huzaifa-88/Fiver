﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Joao_Project_2.BL;

namespace Joao_Project_2.Classes
{
    public static class Session
    {
        public static UserBL CurrentUser { get; set; }
    }
}
