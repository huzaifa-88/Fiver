﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joao_Project_2.Classes
{
    public abstract class Operation
    {
        private DateTime Date;
        private Money amount;


        protected Operation(DateTime date, Money amount) 
        {
            Date = date;
            Amount = amount;
        }
        public DateTime Date1 { get => Date; set => Date = value; }
        public Money Amount { get => amount; set => amount = value; }
    }
}
