﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Joao_Project_2.Classes
{
    public class Income : Operation
    {
        public IncomeType Type { get; set; }
        public Income(DateTime date, Money amount, IncomeType type) : base(date, amount)
        {
            Type = type;
        }
    }
}
