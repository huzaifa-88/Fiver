﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Joao_Project_2.BL;
using Joao_Project_2.Classes;
using Joao_Project_2.DL;

namespace Joao_Project_2.UI
{
    internal class UserUI
    {
        public static int userMenu()
        {
            Console.WriteLine("1. Register Yourself");
            Console.WriteLine("2. Already have an Account");
            Console.Write("Enter your choice:");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }
        public static void ClearScreen()
        {
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
            Console.Clear();
        }

        public static int MainMenu()
        {
            Console.WriteLine("\nWelcome to Personal Finance Manager!");
            Console.WriteLine("1. Create Wallet");
            Console.WriteLine("2. Activate Wallet");
            Console.WriteLine("3. View All Wallets");
            Console.WriteLine("4. Logout");
            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            return choice;
        }
    }
}
