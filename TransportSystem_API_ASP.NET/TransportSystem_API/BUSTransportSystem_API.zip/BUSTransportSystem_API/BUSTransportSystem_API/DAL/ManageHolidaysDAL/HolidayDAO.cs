﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using BUSTransportSystem_API.Models;
using BUSTransportSystem_API.Models.ManageHolidays;

namespace BUSTransportSystem_API.DAL
{
    public class HolidayDAO
    {
        private readonly string _connectionString;

        public HolidayDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Add a new holiday
        public int AddHoliday(Holiday holiday)
        {
            if (holiday == null)
            {
                throw new ArgumentNullException(nameof(holiday), "Holiday data cannot be null.");
            }

            // Validate dates before using them
            if (holiday.StartDate == default(DateTime) || holiday.EndDate == default(DateTime))
            {
                throw new ArgumentException("StartDate and EndDate must be valid DateTime values.");
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "INSERT INTO Holidays (HolidayName, StartDate, EndDate, IsSchoolVacation, HolidayType) " +
                            "VALUES (@HolidayName, @StartDate, @EndDate, @IsSchoolVacation, @HolidayType); " +
                            "SELECT SCOPE_IDENTITY();";  // Get the newly inserted HolidayID

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@HolidayName", holiday.HolidayName);
                    command.Parameters.AddWithValue("@StartDate", holiday.StartDate);
                    command.Parameters.AddWithValue("@EndDate", holiday.EndDate);
                    command.Parameters.AddWithValue("@IsSchoolVacation", holiday.IsSchoolVacation);
                    command.Parameters.AddWithValue("@HolidayType", holiday.HolidayType);  // Include HolidayType

                    return Convert.ToInt32(command.ExecuteScalar());  // Return the generated HolidayID
                }
            }
        }


        // Get all holidays
        public List<Holiday> GetAllHolidays()
        {
            var holidays = new List<Holiday>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Holidays";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            holidays.Add(new Holiday
                            {
                                HolidayID = reader.GetInt32(0),
                                HolidayName = reader.GetString(1),
                                StartDate = reader.GetDateTime(2),
                                EndDate = reader.GetDateTime(3),
                                IsSchoolVacation = reader.GetBoolean(4),
                                HolidayType = reader.GetString(5)
                            });
                        }
                    }
                }
            }
            return holidays;
        }


        // Update an existing holiday
        public void UpdateHoliday(Holiday holiday)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "UPDATE Holidays SET HolidayName = @HolidayName, StartDate = @StartDate, " +
                            "EndDate = @EndDate, IsSchoolVacation = @IsSchoolVacation, HolidayType = @HolidayType " +
                            "WHERE HolidayName = @HolidayName AND HolidayType = @HolidayType";
                using (var command = new SqlCommand(query, connection))
                {
                    // Parameters for updating the holiday fields
                    command.Parameters.AddWithValue("@HolidayName", holiday.HolidayName);
                    command.Parameters.AddWithValue("@StartDate", holiday.StartDate);
                    command.Parameters.AddWithValue("@EndDate", holiday.EndDate);
                    command.Parameters.AddWithValue("@IsSchoolVacation", holiday.IsSchoolVacation);
                    command.Parameters.AddWithValue("@HolidayType", holiday.HolidayType);  // Added for HolidayType

                    command.ExecuteNonQuery();
                }
            }
        }


        // Delete a holiday
        public void DeleteHolidayByName(string holidayName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Check if the holiday exists first
                var checkQuery = "SELECT COUNT(*) FROM Holidays WHERE HolidayName = @HolidayName";
                using (var checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@HolidayName", holidayName);
                    int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                    if (count == 0)
                    {
                        throw new Exception("Holiday with the specified name not found.");
                    }
                }

                // Delete the holiday if it exists
                var deleteQuery = "DELETE FROM Holidays WHERE HolidayName = @HolidayName";
                using (var command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@HolidayName", holidayName);
                    command.ExecuteNonQuery();
                }
            }
        }

        public Holiday GetHolidayByNameAndType(string holidayName, string holidayType)
        {
            Holiday holiday = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Holidays WHERE HolidayName = @HolidayName AND HolidayType = @HolidayType";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@HolidayName", holidayName);
                    command.Parameters.AddWithValue("@HolidayType", holidayType);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            holiday = new Holiday
                            {
                                HolidayID = reader.GetInt32(0),
                                HolidayName = reader.GetString(1),
                                StartDate = reader.GetDateTime(2),
                                EndDate = reader.GetDateTime(3),
                                IsSchoolVacation = reader.GetBoolean(4),
                                HolidayType = reader.GetString(5)  // Assuming it's the 6th column
                            };
                        }
                    }
                }
            }

            return holiday; // Will be null if not found
        }
    }
}
