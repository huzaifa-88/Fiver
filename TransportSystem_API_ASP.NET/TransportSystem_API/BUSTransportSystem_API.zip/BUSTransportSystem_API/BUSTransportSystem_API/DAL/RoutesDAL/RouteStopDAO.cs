﻿using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.DAL.RoutesDAL
{
    public class RouteStopDAO
    {
        private readonly string _connectionString;

        public RouteStopDAO(string connectionString)
        {
            _connectionString = connectionString;
        }
        public bool AddStopToRoute(int routeID, int stopID, int sequence, TimeSpan departureTime)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = "INSERT INTO RouteStops (RouteID, StopID, Sequence, DepartureTime) " +
                            "VALUES (@RouteID, @StopID, @Sequence, @DepartureTime)";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RouteID", routeID);
                    command.Parameters.AddWithValue("@StopID", stopID);
                    command.Parameters.AddWithValue("@Sequence", sequence);
                    command.Parameters.AddWithValue("@DepartureTime", departureTime);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }

        public int? GetStopIDByName(string stopName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT StopID FROM Stops WHERE StopName = @StopName";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StopName", stopName);
                    var result = command.ExecuteScalar();
                    return result != null ? (int?)result : null;
                }
            }
        }

        public int? GetRouteIDByName(string routeName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT RouteID FROM Routes WHERE RouteName = @RouteName";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RouteName", routeName);
                    var result = command.ExecuteScalar();
                    return result != null ? (int?)result : null;
                }
            }
        }



    }
}
