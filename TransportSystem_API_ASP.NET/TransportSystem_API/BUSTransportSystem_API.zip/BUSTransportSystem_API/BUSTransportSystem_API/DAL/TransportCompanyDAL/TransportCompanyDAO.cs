﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using static BUSTransportSystem_API.Models.TransportCompanies.TransportCompanyModel;
using Microsoft.AspNetCore.Identity;

namespace BUSTransportSystem_API.DAL.TransportCompanyDAL
{
    public class TransportCompanyDAO
    {
        private readonly string _connectionString;
        private readonly PasswordHasher<TransportCompany> _passwordHasher = new PasswordHasher<TransportCompany>();

        public TransportCompanyDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        public int AddTransportCompany(TransportCompany company)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "INSERT INTO TransportCompanies (CompanyName, ContactEmail, PhoneNumber, Password) " +
                            "VALUES (@CompanyName, @ContactEmail, @PhoneNumber, @Password); " +
                            "SELECT SCOPE_IDENTITY();";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CompanyName", company.CompanyName);
                    command.Parameters.AddWithValue("@ContactEmail", company.ContactEmail);
                    command.Parameters.AddWithValue("@PhoneNumber", company.PhoneNumber);

                    // Hash the password before storing it in the database
                    string hashedPassword = _passwordHasher.HashPassword(company, company.Password);
                    command.Parameters.AddWithValue("@Password", hashedPassword);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        public List<TransportCompany> GetTransportCompanies()
        {
            var companies = new List<TransportCompany>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM TransportCompanies";
                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            companies.Add(new TransportCompany
                            {
                                CompanyID = reader.GetInt32(0),
                                CompanyName = reader.GetString(1),
                                ContactEmail = reader.GetString(2),
                                PhoneNumber = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Password = reader.GetString(4),
                                RegisteredDate = reader.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            return companies;
        }
        public bool VerifyLoginCredentials(string contactEmail, string enteredPassword)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM TransportCompanies WHERE ContactEmail = @ContactEmail";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ContactEmail", contactEmail);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Get the stored hashed password from the database (assuming it's in the 5th column)
                            string storedPasswordHash = reader.GetString(4); // Column index for password (5th column)

                            // Create a TransportCompany object with the entered password
                            var company = new TransportCompany { Password = enteredPassword };

                            // Verify the entered password with the stored hashed password
                            var verificationResult = _passwordHasher.VerifyHashedPassword(company, storedPasswordHash, enteredPassword);

                            return verificationResult == PasswordVerificationResult.Success;
                        }
                    }
                }
            }

            return false; // Return false if no matching record found
        }

    }
}
