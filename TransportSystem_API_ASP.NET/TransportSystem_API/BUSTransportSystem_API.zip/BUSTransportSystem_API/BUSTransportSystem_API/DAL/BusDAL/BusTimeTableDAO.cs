﻿using BUSTransportSystem_API.Models.Bus;
using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.DAL.B_TimeTableDAL
{
    public class BusTimeTableDAO
    {
        private readonly string _connectionString;

        public BusTimeTableDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        public int GetBusIdByNumber(string busNumber)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT BusID FROM Buses WHERE BusNumber = @BusNumber", connection))
                {
                    command.Parameters.AddWithValue("@BusNumber", busNumber);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        public int GetRouteIdByNumber(int routeNumber)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT RouteID FROM Routes WHERE RouteNumber = @RouteNumber", connection))
                {
                    command.Parameters.AddWithValue("@RouteNumber", routeNumber);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        public int GetRouteStopIdByRouteNumberAndStopName(int routeNumber, string stopName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = @"SELECT rs.RouteStopID
                              FROM RouteStops rs
                              JOIN Routes r ON rs.RouteID = r.RouteID
                              JOIN Stops s ON rs.StopID = s.StopID
                              WHERE r.RouteNumber = @RouteNumber AND s.StopName = @StopName";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RouteNumber", routeNumber);
                    command.Parameters.AddWithValue("@StopName", stopName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        public bool AddBusTimeTable(int busId, int routeStopId, DateTime arrivalTime, DateTime departureTime, string dayOfWeek, bool isHolidayApplicable)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO BusTimeTable (BusID, RouteStopID, ArrivalTime, DepartureTime, DayOfWeek, IsHolidayApplicable) VALUES (@BusID, @RouteStopID, @ArrivalTime, @DepartureTime, @DayOfWeek, @IsHolidayApplicable)", connection))
                {
                    command.Parameters.AddWithValue("@BusID", busId);
                    command.Parameters.AddWithValue("@RouteStopID", routeStopId);
                    command.Parameters.AddWithValue("@ArrivalTime", arrivalTime);
                    command.Parameters.AddWithValue("@DepartureTime", departureTime);
                    command.Parameters.AddWithValue("@DayOfWeek", dayOfWeek);
                    command.Parameters.AddWithValue("@IsHolidayApplicable", isHolidayApplicable);

                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
        }

        public int GetStopIdByName(string stopName)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    var query = "SELECT StopID FROM Stops WHERE StopName = @StopName";
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StopName", stopName);
                        var result = command.ExecuteScalar();
                        return result != null ? Convert.ToInt32(result) : -1;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching StopID for StopName '{stopName}': {ex.Message}");
                return -1;
            }
        }

        public List<DisplayBoardDTO> GetNextDepartures(int stopId, DateTime queryTime, int numberOfConnections)
        {
            var departures = new List<DisplayBoardDTO>();
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    var query = @"SELECT TOP (@NumberOfConnections) 
                                       bt.DepartureTime, 
                                       r.RouteNumber, 
                                       b.BusNumber, 
                                       s.StopName AS EndStation, 
                                       bt.DelayInMinutes 
                                   FROM BusTimeTable bt
                                   JOIN RouteStops rs ON bt.RouteStopID = rs.RouteStopID
                                   JOIN Routes r ON rs.RouteID = r.RouteID
                                   JOIN Buses b ON bt.BusID = b.BusID
                                   JOIN Stops s ON r.EndStopID = s.StopID
                                   WHERE rs.StopID = @StopID AND bt.DepartureTime >= @QueryTime
                                   ORDER BY bt.DepartureTime";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@StopID", stopId);
                        command.Parameters.AddWithValue("@QueryTime", queryTime);
                        command.Parameters.AddWithValue("@NumberOfConnections", numberOfConnections);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                departures.Add(new DisplayBoardDTO
                                {
                                    DepartureTime = reader.GetDateTime(0),
                                    RouteNumber = reader.GetInt32(1),
                                    BusNumber = reader.GetString(2),
                                    EndStation = reader.GetString(3),
                                    DelayInMinutes = reader.GetInt32(4)
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching departures: {ex.Message}");
            }

            return departures;
        }
    }
}
