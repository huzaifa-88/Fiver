﻿using BUSTransportSystem_API.Models.Bus;
using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.DAL.BusDAL
{
    public class DelayStatisticsDAO
    {
        private readonly string _connectionString;

        public DelayStatisticsDAO(string connectionString)
        {
            _connectionString = connectionString;
        }
        //----Step 11 
        public List<RouteStatistics> GetDelayStatistics(DateTime startDate, DateTime endDate, int? routeNumber)
        {
            var query = @"
                    SELECT r.RouteNumber,
                           AVG(DATEDIFF(SECOND, btt.ArrivalTime, bc.CheckINArrivalTime)) AS AverageDelaySeconds,
                           SUM(CASE WHEN DATEDIFF(SECOND, btt.ArrivalTime, bc.CheckINArrivalTime) < 120 THEN 1 ELSE 0 END) AS OnTimeCount,
                           SUM(CASE WHEN DATEDIFF(SECOND, btt.ArrivalTime, bc.CheckINArrivalTime) BETWEEN 120 AND 300 THEN 1 ELSE 0 END) AS SlightlyDelayedCount,
                           SUM(CASE WHEN DATEDIFF(SECOND, btt.ArrivalTime, bc.CheckINArrivalTime) BETWEEN 300 AND 600 THEN 1 ELSE 0 END) AS DelayedCount,
                           SUM(CASE WHEN DATEDIFF(SECOND, btt.ArrivalTime, bc.CheckINArrivalTime) > 600 THEN 1 ELSE 0 END) AS SignificantlyDelayedCount
                    FROM BusCheckIns bc
                    JOIN BusTimeTable btt ON bc.RouteStopID = btt.RouteStopID
                    JOIN RouteStops rs ON btt.RouteStopID = rs.RouteStopID  -- Adding this join
                    JOIN Routes r ON rs.RouteID = r.RouteID  -- Joining through RouteStops table
                    WHERE bc.CheckINArrivalTime BETWEEN @StartDate AND @EndDate
                    AND (@RouteNumber IS NULL OR r.RouteNumber = @RouteNumber)
                    GROUP BY r.RouteNumber";

            var parameters = new[]
            {
                new SqlParameter("@StartDate", startDate),
                new SqlParameter("@EndDate", endDate),
                new SqlParameter("@RouteNumber", (object)routeNumber ?? DBNull.Value)
            };

            // Call ExecuteReader and return the results
            return ExecuteReader(query, parameters);
        }
        private List<RouteStatistics> ExecuteReader(string query, SqlParameter[] parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand(query, connection);
                command.Parameters.AddRange(parameters);
                connection.Open();
                var reader = command.ExecuteReader();
                var results = new List<RouteStatistics>();

                while (reader.Read())
                {
                    // Use the MapRouteStatistics helper to map the data
                    var routeStats = MapRouteStatistics(reader);

                    // Add the mapped result to the list
                    results.Add(routeStats);
                }

                return results;
            }
        }

        private RouteStatistics MapRouteStatistics(SqlDataReader reader)
        {
            int routeNumber = reader.IsDBNull(reader.GetOrdinal("RouteNumber")) ? 0 : reader.GetInt32(reader.GetOrdinal("RouteNumber"));
            int averageDelaySeconds = reader.IsDBNull(reader.GetOrdinal("AverageDelaySeconds")) ? 0 : reader.GetInt32(reader.GetOrdinal("AverageDelaySeconds"));
            int onTimeCount = reader.IsDBNull(reader.GetOrdinal("OnTimeCount")) ? 0 : reader.GetInt32(reader.GetOrdinal("OnTimeCount"));
            int slightlyDelayedCount = reader.IsDBNull(reader.GetOrdinal("SlightlyDelayedCount")) ? 0 : reader.GetInt32(reader.GetOrdinal("SlightlyDelayedCount"));
            int delayedCount = reader.IsDBNull(reader.GetOrdinal("DelayedCount")) ? 0 : reader.GetInt32(reader.GetOrdinal("DelayedCount"));
            int significantlyDelayedCount = reader.IsDBNull(reader.GetOrdinal("SignificantlyDelayedCount")) ? 0 : reader.GetInt32(reader.GetOrdinal("SignificantlyDelayedCount"));

            return new RouteStatistics
            {
                RouteNumber = routeNumber,
                AverageDelaySeconds = averageDelaySeconds,
                OnTimePercentage = CalculatePercentage(onTimeCount, reader),
                SlightlyDelayedPercentage = CalculatePercentage(slightlyDelayedCount, reader),
                DelayedPercentage = CalculatePercentage(delayedCount, reader),
                SignificantlyDelayedPercentage = CalculatePercentage(significantlyDelayedCount, reader)
            };
        }




        private double CalculatePercentage(int count, SqlDataReader reader)
        {
            var total = reader.GetInt32(2) + reader.GetInt32(3) + reader.GetInt32(4) + reader.GetInt32(5);
            return total > 0 ? (double)count / total * 100 : 0;
        }
    }

}
