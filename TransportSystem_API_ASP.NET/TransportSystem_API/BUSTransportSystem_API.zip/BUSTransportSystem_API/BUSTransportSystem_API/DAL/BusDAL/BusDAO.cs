﻿using System.Data;
using BUSTransportSystem_API.Models.Bus;
using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.DAL.BusDAL
{
    public class BusDAO
    {
        private readonly string _connectionString;

        public BusDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Add a new bus

        public bool AddBus(int companyId, string busNumber, int capacity)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Check if the CompanyID exists in the TransportCompanies table
                    using (var checkCommand = new SqlCommand("SELECT COUNT(1) FROM TransportCompanies WHERE CompanyID = @CompanyID", connection))
                    {
                        checkCommand.Parameters.AddWithValue("@CompanyID", companyId);

                        int companyExists = (int)checkCommand.ExecuteScalar();
                        if (companyExists == 0)
                        {
                            // If company doesn't exist, return false
                            return false;
                        }
                    }

                    // If company exists, proceed with inserting the bus record
                    using (var command = new SqlCommand("INSERT INTO Buses (CompanyID, BusNumber, Capacity) VALUES (@CompanyID, @BusNumber, @Capacity)", connection))
                    {
                        command.Parameters.AddWithValue("@CompanyID", companyId);
                        command.Parameters.AddWithValue("@BusNumber", busNumber);
                        command.Parameters.AddWithValue("@Capacity", capacity);

                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0; // Return true if the bus was added successfully, otherwise false
                    }
                }
            }
            catch (SqlException ex)
            {
                // Log the SQL error (optional)
                return false; // Return false if a SQL error occurs
            }
            catch (Exception ex)
            {
                // Log the general error (optional)
                return false; // Return false for any other unexpected errors
            }
        }
        public int? GetCompanyIdByEmail(string contactEmail)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Query to get CompanyID based on ContactEmail
                    using (var command = new SqlCommand("SELECT CompanyID FROM TransportCompanies WHERE ContactEmail = @ContactEmail", connection))
                    {
                        command.Parameters.AddWithValue("@ContactEmail", contactEmail);

                        var result = command.ExecuteScalar();
                        if (result != null)
                        {
                            return (int?)result;  // Return CompanyID if found
                        }
                        else
                        {
                            return null;  // Return null if no company is found
                        }
                    }
                }
            }
            catch (SqlException)
            {
                return null;  // Return null if an error occurs
            }
            catch (Exception)
            {
                return null;  // Return null for any other unexpected errors
            }
        }

        public Bus GetBusByBusNumber(string busNumber)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT BusID, CompanyID, BusNumber, Capacity FROM Buses WHERE BusNumber = @BusNumber", connection))
                {
                    command.Parameters.AddWithValue("@BusNumber", busNumber);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Bus
                            {
                                BusID = reader.GetInt32(0),
                                CompanyID = reader.GetInt32(1),
                                BusNumber = reader.GetString(2),
                                Capacity = reader.GetInt32(3)
                            };
                        }
                    }
                }
            }
            return null;
        }

        // Retrieve all buses
        public List<Bus> GetAllBuses()
        {
            var buses = new List<Bus>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT BusID, CompanyID, BusNumber, Capacity FROM Buses", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buses.Add(new Bus
                            {
                                BusID = reader.GetInt32(0),
                                CompanyID = reader.GetInt32(1),
                                BusNumber = reader.GetString(2),
                                Capacity = reader.GetInt32(3)
                            });
                        }
                    }
                }
            }
            return buses;
        }

        // Delete a bus by ID
        public bool DeleteBusByNumber(string busNumber)
        {
            if (string.IsNullOrWhiteSpace(busNumber))
            {
                Console.WriteLine("Invalid bus number provided.");
                return false; // Early exit if busNumber is null or empty
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Step 1: Directly attempt to delete the bus by BusNumber
                using (var deleteCommand = new SqlCommand("DELETE FROM Buses WHERE BusNumber = @BusNumber", connection))
                {
                    // Parameterize the query to avoid SQL injection
                    deleteCommand.Parameters.Add("@BusNumber", SqlDbType.NVarChar, 50).Value = busNumber.Trim();

                    // Execute the delete command
                    int rowsAffected = deleteCommand.ExecuteNonQuery();
                    return rowsAffected > 0; // True if deletion was successful
                }
            }
        }


    }
}
