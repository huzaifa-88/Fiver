﻿using BUSTransportSystem_API.Models.Bus;
using BUSTransportSystem_API.Models.Routes;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BUSTransportSystem_API.DAL.BusDAL
{
    public class BusCheckInDAO
    {
        private readonly string _connectionString;

        public BusCheckInDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Log Bus Check-In with ArrivalTime and Delay
        public void LogBusCheckIn(int routeStopId, int busId, DateTime actualArrivalTime, int delay)
        {
            var query = "INSERT INTO BusCheckIns (BusID, RouteStopID, CheckINArrivalTime, Delay) " +
                        "VALUES (@BusID, @RouteStopID, @CheckINArrivalTime, @Delay)";

            var parameters = new[]
            {
                new SqlParameter("@BusID", busId),
                new SqlParameter("@RouteStopID", routeStopId),
                new SqlParameter("@CheckINArrivalTime", actualArrivalTime),
                new SqlParameter("@Delay", delay)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Get RouteStopID by RouteNumber and StopName
        public int GetRouteStopIdByRouteNumberAndStopName(int routeNumber, string stopName)
        {
            var query = "SELECT rs.RouteStopID FROM RouteStops rs " +
                        "INNER JOIN Routes r ON rs.RouteID = r.RouteID " +
                        "INNER JOIN Stops s ON rs.StopID = s.StopID " +
                        "WHERE r.RouteNumber = @RouteNumber AND s.StopName = @StopName";

            var parameters = new[]
            {
                new SqlParameter("@RouteNumber", routeNumber),
                new SqlParameter("@StopName", stopName)
            };

            return ExecuteScalar<int>(query, parameters);
        }

        // Get expected arrival time from BusTimeTable using RouteStopID
        public DateTime? GetExpectedArrivalTimeFromBusTimeTable(int routeStopId)
        {
            var query = "SELECT ArrivalTime FROM BusTimeTable WHERE RouteStopID = @RouteStopID";
            var parameters = new[]
            {
                new SqlParameter("@RouteStopID", routeStopId)
            };

            return ExecuteScalar<DateTime?>(query, parameters);
        }

        // Fetch BusID based on BusNumber
        public int GetBusIdByBusNumber(string busNumber)
        {
            var query = "SELECT BusID FROM Buses WHERE BusNumber = @BusNumber";
            var parameters = new[]
            {
                new SqlParameter("@BusNumber", busNumber)
            };

            return ExecuteScalar<int>(query, parameters);
        }

        // Propagate delay to subsequent stops on the same route
        public void PropagateDelay(int routeStopId, int busId, int delay)
        {
            var subsequentStops = GetSubsequentStops(routeStopId);

            foreach (var stop in subsequentStops)
            {
                UpdateExpectedArrivalTime(stop.RouteStopID, busId, delay);
            }
        }

        // Get subsequent stops based on RouteStopID
        private List<RouteStop> GetSubsequentStops(int routeStopId)
        {
            var query = "SELECT RouteStopID FROM RouteStops WHERE RouteStopID > @RouteStopID ORDER BY RouteStopID";
            var parameters = new[]
            {
                new SqlParameter("@RouteStopID", routeStopId)
            };

            var stopIds = ExecuteReader<int>(query, parameters);
            return stopIds.Select(id => new RouteStop { RouteStopID = id }).ToList();
        }

        // Update the expected arrival time in BusTimeTable
        private void UpdateExpectedArrivalTime(int routeStopId, int busId, int delay)
        {
            var query = "UPDATE BusTimeTable SET ArrivalTime = DATEADD(MINUTE, @Delay, ArrivalTime) " +
                        "WHERE RouteStopID = @RouteStopID";

            var parameters = new[]
            {
                new SqlParameter("@RouteStopID", routeStopId),
                new SqlParameter("@Delay", delay)
            };

            ExecuteNonQuery(query, parameters);
        }

        // Execute non-query SQL commands (INSERT, UPDATE, DELETE)
        private void ExecuteNonQuery(string query, SqlParameter[] parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand(query, connection);
                command.Parameters.AddRange(parameters);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        // Execute SQL queries that return a single value (e.g., COUNT, SUM, etc.)
        private T ExecuteScalar<T>(string query, SqlParameter[] parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand(query, connection);
                command.Parameters.AddRange(parameters);
                connection.Open();

                var result = command.ExecuteScalar();

                // Handle null or DBNull values gracefully
                if (result == DBNull.Value || result == null)
                {
                    return default(T); // Return default value of T if result is null
                }

                return (T)result;
            }
        }

        // Execute SQL queries that return a list of values (e.g., SELECT)
        private List<T> ExecuteReader<T>(string query, SqlParameter[] parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var command = new SqlCommand(query, connection);
                command.Parameters.AddRange(parameters);
                connection.Open();
                var reader = command.ExecuteReader();
                var results = new List<T>();

                while (reader.Read())
                {
                    results.Add((T)reader[0]);
                }

                return results;
            }
        }
    }
}
