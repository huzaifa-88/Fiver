﻿using BUSTransportSystem_API.Models.Passenger;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.DAL.PassengerDAL
{
    public class TimetableQueryDAO
    {
        private readonly string _connectionString;

        public TimetableQueryDAO(string connectionString)
        {
            _connectionString = connectionString;
        }
        //public TimetableQueryDAO(IConfiguration configuration)
        //{
        //    _connectionString = configuration.GetConnectionString("BusTransportSystem");
        //}

        // Get Stop ID based on stop name
        private int GetStopIDByName(string stopName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT StopID FROM Stops WHERE StopName = @StopName", connection))
                {
                    command.Parameters.AddWithValue("@StopName", stopName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
        }

        // Method to query BusTimeTable based on start and destination stops, time, and connections
        public List<BusTimeTableResponse> GetTimetableConnections(int startStopID, int destinationStopID, TimetableQuery request)
        {
            var connections = new List<BusTimeTableResponse>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // Query for direct connections or connections with one transfer
                string query = @"
                SELECT 
                    btt.ArrivalTime, 
                    btt.DepartureTime, 
                    btt.DayOfWeek, 
                    btt.IsHolidayApplicable
                FROM 
                    BusTimeTable btt
                INNER JOIN 
                    Routes r ON btt.RouteID = r.RouteID
                INNER JOIN 
                    RouteStops rsStart ON r.RouteID = rsStart.RouteID
                INNER JOIN 
                    RouteStops rsDest ON r.RouteID = rsDest.RouteID
                WHERE 
                    rsStart.StopID = @StartStopID
                    AND rsDest.StopID = @DestinationStopID
                    AND btt.DayOfWeek = @DayOfWeek
                    AND (btt.IsHolidayApplicable = 0 OR btt.IsHolidayApplicable = 1)
                ORDER BY 
                    btt.DepartureTime;";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StartStopID", startStopID);
                    command.Parameters.AddWithValue("@DestinationStopID", destinationStopID);
                    command.Parameters.AddWithValue("@DayOfWeek", request.QueryDateTime.DayOfWeek.ToString());

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var arrivalTime = reader.GetTimeSpan(0);
                            var departureTime = reader.GetTimeSpan(1);
                            var dayOfWeek = reader.GetString(2);
                            var isHolidayApplicable = reader.GetBoolean(3);

                            connections.Add(new BusTimeTableResponse
                            {
                                ArrivalTime = arrivalTime,
                                DepartureTime = departureTime,
                                DayOfWeek = dayOfWeek,
                                IsHolidayApplicable = isHolidayApplicable
                            });
                        }
                    }
                }
            }

            return connections.Take(request.NumberOfConnections).ToList();
        }

        // Helper method to get Stop ID by name
        public int GetStopID(string stopName)
        {
            return GetStopIDByName(stopName);
        }
    }
}