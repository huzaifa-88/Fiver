﻿using BUSTransportSystem_API.DAL.BusDAL;
using BUSTransportSystem_API.Models.Bus;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Bus_Con
{

    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class BusController : ControllerBase
    {
        private readonly BusDAO _busDao;

        public BusController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _busDao = new BusDAO(connectionString);
        }

        [Authorize]
        [HttpPost("add-bus")]
        public IActionResult AddBus([FromBody] Bus request)
        {
            if (request == null || string.IsNullOrEmpty(request.BusNumber) || request.Capacity <= 0)
            {
                return BadRequest("Invalid bus data.");
            }

            // Extract ContactEmail from JWT Token
            var contactEmail = User.FindFirst("ContactEmail")?.Value;

            if (string.IsNullOrEmpty(contactEmail))
            {
                return Unauthorized("Invalid or missing email in the token.");
            }

            // Get the CompanyID based on the ContactEmail
            var companyId = _busDao.GetCompanyIdByEmail(contactEmail);

            if (companyId == null)
            {
                return Unauthorized("Company not found for the given email.");
            }

            // Add the bus using the retrieved CompanyID
            var isAdded = _busDao.AddBus(companyId.Value, request.BusNumber, request.Capacity);
            if (isAdded)
            {
                return Ok("Bus added successfully.");
            }
            else
            {
                return StatusCode(500, "An error occurred while adding the bus.");
            }
        }

        [HttpGet("{busNumber}")]
        public IActionResult GetBusByBusNumber(string busNumber)
        {
            // Validate BusNumber if needed (for example, check if it's not empty or matches a certain pattern)
            if (string.IsNullOrEmpty(busNumber))
            {
                return BadRequest("BusNumber is required.");
            }

            var bus = _busDao.GetBusByBusNumber(busNumber);
            if (bus == null)
            {
                return NotFound("Bus not found.");
            }

            return Ok(bus);
        }


        // Retrieve all buses
        [HttpGet("all")]
        public IActionResult GetAllBuses()
        {
            var buses = _busDao.GetAllBuses();
            return Ok(buses);
        }

        // Delete a bus by ID
        [HttpDelete("delete/{BusNumber}")]
        public IActionResult DeleteBusByNumber([FromQuery] string busNumber)
        {
            var isDeleted = _busDao.DeleteBusByNumber(busNumber);
            if (isDeleted)
            {
                return Ok("Bus deleted successfully.");
            }
            else
            {
                return NotFound("Bus not found.");
            }
        }
    }
}
