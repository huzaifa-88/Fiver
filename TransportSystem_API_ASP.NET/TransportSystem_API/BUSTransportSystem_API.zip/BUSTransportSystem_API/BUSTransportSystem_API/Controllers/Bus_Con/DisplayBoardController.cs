﻿using BUSTransportSystem_API.DAL.B_TimeTableDAL;
using BUSTransportSystem_API.Models.Bus;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Bus_Con
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class DisplayBoardController : ControllerBase
    {
        private readonly BusTimeTableDAO _busTimeTableDao;
        public DisplayBoardController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _busTimeTableDao = new BusTimeTableDAO(connectionString);
        }

        [HttpGet("get-next-departures")]
        public IActionResult GetNextDepartures(
            [FromQuery] string stopName,
            [FromQuery] DateTime? queryTime = null,
            [FromQuery] int numberOfConnections = 3)
        {
            if (string.IsNullOrEmpty(stopName))
            {
                return BadRequest("Stop name is required. Please enter the current stop name.");
            }

            var effectiveQueryTime = queryTime ?? DateTime.Now;

            var stopId = _busTimeTableDao.GetStopIdByName(stopName);
            if (stopId == -1)
            {
                return NotFound($"No stop found with the name '{stopName}'.");
            }

            var departures = _busTimeTableDao.GetNextDepartures(stopId, effectiveQueryTime, numberOfConnections);

            if (departures == null || !departures.Any())
            {
                return NotFound($"No departures found for stop '{stopName}' at or after {effectiveQueryTime}.");
            }

            return Ok(departures);
        }
    }
}
