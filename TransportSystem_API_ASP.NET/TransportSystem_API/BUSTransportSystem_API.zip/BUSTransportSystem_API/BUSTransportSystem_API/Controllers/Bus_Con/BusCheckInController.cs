﻿using BUSTransportSystem_API.DAL.B_TimeTableDAL;
using BUSTransportSystem_API.DAL.BusDAL;
using BUSTransportSystem_API.Models.Bus;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Bus_Con
{
    //-----------Modified step 9 and also implementation of Step 8
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class BusCheckInController : ControllerBase
    {
        private readonly BusCheckInDAO _dao;


        public BusCheckInController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new BusCheckInDAO(connectionString);
        }
        [HttpPost("add")]
        public IActionResult CheckIn([FromBody] BusCheckIn request)
        {
            try
            {
                // Validate input data
                if (request.RouteNumber <= 0 || string.IsNullOrEmpty(request.StopName) || request.ArrivalTime == null || string.IsNullOrEmpty(request.BusNumber))
                {
                    return BadRequest("RouteNumber, StopName, ArrivalTime, and BusId are required.");
                }

                // Get RouteStopID based on RouteNumber and StopName
                int routeStopId = _dao.GetRouteStopIdByRouteNumberAndStopName(request.RouteNumber, request.StopName);

                if (routeStopId == -1)
                {
                    return NotFound("Invalid RouteNumber or StopName.");
                }

                // Get the expected arrival time from the BusTimeTable using RouteStopID
                var expectedArrivalTime = _dao.GetExpectedArrivalTimeFromBusTimeTable(routeStopId);  //I Will update later

                if (expectedArrivalTime == null)
                {
                    return NotFound("RouteStop not found in BusTimeTable.");
                }

                int busId = _dao.GetBusIdByBusNumber(request.BusNumber);
                if (busId == -1)
                {
                    return NotFound("Invalid BusNumber.");
                }

                // Calculate delay
                var delay = CalculateDelay(expectedArrivalTime.Value, request.ArrivalTime);

                // Log the check-in with ArrivalTime and Delay
                _dao.LogBusCheckIn(routeStopId, busId, request.ArrivalTime, delay);

                // Propagate the delay to subsequent stops on the same route
                _dao.PropagateDelay(routeStopId, busId, delay);

                // Return response with delay information
                return Ok(new
                {
                    Message = "Bus checked in successfully.",
                    Delay = delay
                });
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during the check-in process
                return StatusCode(500, $"Internal_BusCheckInCOn server error: {ex.Message}");
            }
        }

        // Calculate delay in minutes
        private int CalculateDelay(DateTime expectedArrival, DateTime actualArrival)
        {
            return (int)(actualArrival - expectedArrival).TotalMinutes;
        }
    }
}