﻿using BUSTransportSystem_API.DAL.BusDAL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Bus_Con
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class DelayStatisticsController : ControllerBase
    {
        private readonly DelayStatisticsDAO _dao;

        public DelayStatisticsController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new DelayStatisticsDAO(connectionString);
        }

        [HttpGet("delay")]
        public IActionResult GetDelayStatistics([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, [FromQuery] int? routeNumber)
        {
            try
            {
                var statistics = _dao.GetDelayStatistics(startDate, endDate, routeNumber);

                return Ok(statistics);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }

}
