﻿using BUSTransportSystem_API.DAL.B_TimeTableDAL;
using BUSTransportSystem_API.Models.BusTimeTable;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BUSTransportSystem_API.Controllers.Bus_Con
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class BusTimeTableController : ControllerBase
    {
        private readonly BusTimeTableDAO _busTimeTableDao;

        public BusTimeTableController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _busTimeTableDao = new BusTimeTableDAO(connectionString);
        }

        [HttpPost("add")]
        public IActionResult AddBusTimeTable([FromBody] BusTimeTable request)
        {
            if (request == null)
            {
                return BadRequest("Invalid payload. Please check your request structure.");
            }

            // Validate required fields
            if (request.RouteNumber <= 0 || string.IsNullOrWhiteSpace(request.BusNumber))
            {
                return BadRequest("RouteNumber and BusNumber are required.");
            }

            // Proceed with existing logic
            try
            {
                var routeStopID = _busTimeTableDao.GetRouteStopIdByRouteNumberAndStopName(request.RouteNumber, request.StopName);

                if (routeStopID == -1)
                {
                    return NotFound("RouteStopID not found for the provided RouteNumber and StopName.");
                }

                var busID = _busTimeTableDao.GetBusIdByNumber(request.BusNumber);

                if (busID == -1)
                {
                    return NotFound("Bus not found for the provided BusNumber.");
                }

                var isAdded = _busTimeTableDao.AddBusTimeTable(
                    busID,
                    routeStopID,
                    request.ArrivalTime,
                    request.DepartureTime,
                    request.DayOfWeek,
                    request.IsHolidayApplicable
                );

                if (isAdded)
                {
                    return Ok("Timetable added successfully.");
                }
                else
                {
                    return StatusCode(500, "An error occurred while adding the timetable.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }
    }
}
