﻿using BUSTransportSystem_API.DAL.RoutesDAL;
using BUSTransportSystem_API.DAL.TransportCompanyDAL;
using BUSTransportSystem_API.Models.Routes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace BUSTransportSystem_API.Controllers.Routes_Con
{
    [ApiController]
    [Route("api/routes")]
    public class RouteController : ControllerBase
    {
        private readonly RouteDAO _dao;

        public RouteController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new RouteDAO(connectionString);
        }

        [HttpPost("createRoute")]
        public IActionResult CreateRoute([FromBody] BusRoute route)
        {
            try
            {
                // Validate route number
                if (route.RouteNumber <= 0)
                {
                    return BadRequest("Route number must be a positive integer.");
                }

                // Ensure RouteName is provided
                if (string.IsNullOrEmpty(route.RouteName))
                {
                    return BadRequest("Route name is required.");
                }

                // Insert the new route into the database
                var newRouteID = _dao.AddRoute(route);

                return Ok(new { Message = "Route created successfully.", RouteID = newRouteID });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }

}
