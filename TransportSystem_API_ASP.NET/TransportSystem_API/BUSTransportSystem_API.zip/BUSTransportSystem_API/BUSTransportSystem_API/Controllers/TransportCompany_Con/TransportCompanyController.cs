﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using static BUSTransportSystem_API.Models.TransportCompanies.TransportCompanyModel;
using Microsoft.AspNetCore.Identity.Data;
using System.Text.Json;
using BUSTransportSystem_API.Models.TransportCompanies;
using BUSTransportSystem_API.DAL.TransportCompanyDAL;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authorization;

namespace BUSTransportSystem_API.Controllers.TransportCompany_Con
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransportCompanyController : ControllerBase
    {
        private readonly TransportCompanyDAO _dao;
        private readonly IConfiguration _configuration;

        public TransportCompanyController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new TransportCompanyDAO(connectionString);
            this._configuration = configuration;
        }

        [HttpPost("register")]
        public IActionResult RegisterTransportCompany([FromBody] TransportCompany company)
        {
            try
            {
                var newId = _dao.AddTransportCompany(company);
                return Ok(new { CompanyID = newId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [Authorize]
        [HttpGet("get-all")]
        public IActionResult GetAllTransportCompanies()
        {
            try
            {
                var companies = _dao.GetTransportCompanies();
                return Ok(companies);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("login")]
        public IActionResult LoginTransportCompany([FromBody] LoginCredentials credentials)
        {
            try
            {
                if (string.IsNullOrEmpty(credentials.ContactEmail) || string.IsNullOrEmpty(credentials.Password))
                {
                    return BadRequest("Email and password are required.");
                }

                bool isValid = _dao.VerifyLoginCredentials(credentials.ContactEmail, credentials.Password);


                if (isValid)
                {
                    var claims = new[]
                    {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim("ContactEmail", credentials.ContactEmail.ToString()),
                        new Claim("Password", credentials.Password.ToString())
                    };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:SecretKey"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        _configuration["Jwt:Issuer"],
                        _configuration["Jwt:Audience"],
                        claims,
                        expires: DateTime.UtcNow.AddHours(2),
                        signingCredentials: signIn
                    );

                    string tokenValue = new JwtSecurityTokenHandler().WriteToken(token);

                    return Ok(new { Message = "Login successful", Token = tokenValue });
                }
                else
                {
                    return Unauthorized(new { Message = "Invalid email or password" });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
