﻿using BUSTransportSystem_API.DAL.PassengerDAL;
using BusTransportSystem_API.DAL;
using BUSTransportSystem_API.Models.Passenger;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using BUSTransportSystem_API.DAL.BusDAL;

namespace BUSTransportSystem_API.Controllers.Passenger_Con
{
    [Route("api/[controller]")]
    [ApiController]
    public class TimetableQueryController : ControllerBase
    {
        private readonly TimetableQueryDAO _timetableQueryDAO;

        public TimetableQueryController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _timetableQueryDAO = new TimetableQueryDAO(connectionString);
        }
        [HttpPost]
        public IActionResult GetTimetableQuery([FromBody] TimetableQuery request)
        {
            // Step 1: Get StartStopID and DestinationStopID
            int startStopID = _timetableQueryDAO.GetStopID(request.StartStopName);
            int destinationStopID = _timetableQueryDAO.GetStopID(request.DestinationStopName);

            if (startStopID == -1 || destinationStopID == -1)
            {
                return NotFound("Start or destination stop not found.");
            }

            // Step 2: Query BusTimeTable for connections
            var timetableConnections = _timetableQueryDAO.GetTimetableConnections(startStopID, destinationStopID, request);

            if (timetableConnections.Count == 0)
            {
                return NotFound("No connections found for the given query.");
            }

            // Step 3: Return the timetable connections
            return Ok(timetableConnections);
        }
    }

}
