﻿using Microsoft.AspNetCore.Mvc;
using BUSTransportSystem_API.Models;
using BusTransportSystem_API.DAL;
using System;
using BUSTransportSystem_API.Models.Stops;

namespace BusTransportSystem_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StopController : ControllerBase
    {
        private readonly StopDAO _dao;

        public StopController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new StopDAO(connectionString);
        }

        // Create a new stop
        [HttpPost("create")]
        public IActionResult CreateStop([FromBody] Stop stop)
        {
            try
            {
                if (stop == null)
                {
                    return BadRequest("Stop details are required.");
                }

                // Validate short designation for spaces or special characters
                if (string.IsNullOrEmpty(stop.ShortDesignation) || stop.ShortDesignation.Contains(" ") || !System.Text.RegularExpressions.Regex.IsMatch(stop.ShortDesignation, @"^[a-zA-Z0-9]+$"))
                {
                    return BadRequest("Short Designation must be unique and contain only alphanumeric characters without spaces.");
                }

                var newStopID = _dao.AddStop(stop);
                return Ok(new { StopID = newStopID });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Edit an existing stop
        [HttpPut("edit")]
        public IActionResult EditStop([FromBody] Stop stop)
        {
            try
            {
                if (stop == null)
                {
                    return BadRequest("Stop details are required.");
                }

                // Validate short designation for spaces or special characters
                if (string.IsNullOrEmpty(stop.ShortDesignation) || stop.ShortDesignation.Contains(" ") || !System.Text.RegularExpressions.Regex.IsMatch(stop.ShortDesignation, @"^[a-zA-Z0-9]+$"))
                {
                    return BadRequest("Short Designation must be unique and contain only alphanumeric characters without spaces.");
                }

                // Check if the stop exists in the database before updating
                var existingStop = _dao.GetStopByShortDesignation(stop.ShortDesignation);
                if (existingStop == null)
                {
                    return NotFound(new { Message = "Stop not found." });
                }

                // If stop exists, proceed with updating
                _dao.UpdateStop(stop);
                return Ok(new { Message = "Stop updated successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("search")]
        public IActionResult SearchStops([FromQuery] string searchTerm, [FromQuery] decimal? latitude, [FromQuery] decimal? longitude)
        {
            if (string.IsNullOrEmpty(searchTerm) && (!latitude.HasValue || !longitude.HasValue))
            {
                return BadRequest("Provide a search term or GPS coordinates.");
            }

            List<Stop> stops = _dao.SearchStops(searchTerm, latitude, longitude);
            return Ok(stops);
        }

    }
}
