﻿namespace BUSTransportSystem_API.Models.Passenger
{
    public class BusTimeTableResponse
    {
        public TimeSpan ArrivalTime { get; set; }
        public TimeSpan DepartureTime { get; set; }
        public string DayOfWeek { get; set; }
        public bool IsHolidayApplicable { get; set; }
    }
}
