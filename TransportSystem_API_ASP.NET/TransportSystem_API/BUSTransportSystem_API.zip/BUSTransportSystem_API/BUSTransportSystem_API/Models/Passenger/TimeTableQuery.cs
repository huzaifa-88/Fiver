﻿namespace BUSTransportSystem_API.Models.Passenger
{

    public class TimetableQuery
    {
        public string StartStopName { get; set; }
        public string DestinationStopName { get; set; }
        public DateTime QueryDateTime { get; set; }  // Date and Time of the query
        public int NumberOfConnections { get; set; }  // Number of connections to return
        public bool IsArrivalTime { get; set; }
        //public int QueryID { get; set; }
        //public int PassengerID { get; set; }
        //public string StartStopName { get; set; } // Accept stop names
        //public string DestinationStopName { get; set; } // Accept stop names
        //public DateTime QueryDateTime { get; set; }
        //public DateTime? DepartureDateTime { get; set; }
        //public bool IsArrivalTime { get; set; }
        //public int NumberOfConnections { get; set; }
        //public int StartStopID { get; set; } // This will be derived from StartStopName
        //public int DestinationStopID { get; set; } // This will be derived from DestinationStopName
    }

    //public class TimetableQuery
    //{
    //    public int QueryID { get; set; }
    //    public int PassengerID { get; set; }
    //    public int StartStopID { get; set; }
    //    public int DestinationStopID { get; set; }
    //    public DateTime QueryDateTime { get; set; }
    //    public DateTime? DepartureDateTime { get; set; }
    //    public bool IsArrivalTime { get; set; }
    //    public int NumberOfConnections { get; set; }
    //}

}
