﻿using BUSTransportSystem_API.Models.Stops;

namespace BUSTransportSystem_API.Models.Routes
{
    public class BusRoute
    {
        public int RouteNumber { get; set; }
        public string RouteName { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidUntil { get; set; }
        public string DailyValidity { get; set; }
        public string StartStopName { get; set; } // Provided by user
        public string EndStopName { get; set; } // Provided by user
    }

}
