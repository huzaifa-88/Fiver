﻿namespace BUSTransportSystem_API.Models.Bus
{
    public class RouteStatistics
    {
        public int RouteNumber { get; set; }           // Route number (e.g., 404)
        public double AverageDelaySeconds { get; set; } // Average delay in seconds
        public double OnTimePercentage { get; set; }    // Percentage of stops on time
        public double SlightlyDelayedPercentage { get; set; } // Percentage of slightly delayed stops
        public double DelayedPercentage { get; set; }   // Percentage of delayed stops
        public double SignificantlyDelayedPercentage { get; set; } // Percentage of significantly delayed stops
    }

}
