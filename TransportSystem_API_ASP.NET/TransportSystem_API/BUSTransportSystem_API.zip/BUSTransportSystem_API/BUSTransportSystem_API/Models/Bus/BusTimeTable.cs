﻿namespace BUSTransportSystem_API.Models.BusTimeTable
{
    public class BusTimeTable
    {
        public string BusNumber { get; set; }
        public int RouteNumber { get; set; }
        public string StopName { get; set; }
        public DateTime ArrivalTime { get; set; }
        public DateTime DepartureTime { get; set; }
        public string DayOfWeek { get; set; }
        public bool IsHolidayApplicable { get; set; }

    }
}
