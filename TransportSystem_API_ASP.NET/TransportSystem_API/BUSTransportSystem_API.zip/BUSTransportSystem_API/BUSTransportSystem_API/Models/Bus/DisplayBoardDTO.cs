﻿namespace BUSTransportSystem_API.Models.Bus
{
    public class DisplayBoardDTO
    {
        public DateTime DepartureTime { get; set; }
        public int RouteNumber { get; set; }
        public string BusNumber { get; set; }
        public string EndStation { get; set; }
        public int DelayInMinutes { get; set; }
    }
}
