﻿namespace BUSTransportSystem_API.Models.Bus
{
    public class Bus
    {
        public int BusID { get; set; }         // BusID: Primary Key, auto-incremented
        public int CompanyID { get; set; }     // CompanyID: Foreign Key referencing TransportCompanies table
        public string BusNumber { get; set; }  // BusNumber: Unique identifier for each bus
        public int Capacity { get; set; }
    }
}
