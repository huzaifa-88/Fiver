﻿namespace BUSTransportSystem_API.Models.Bus
{
    public class BusCheckIn
    {
        public string BusNumber { get; set; }
        public int RouteNumber { get; set; }
        public string StopName { get; set; }
        public DateTime ArrivalTime { get; set; }
    }

}
