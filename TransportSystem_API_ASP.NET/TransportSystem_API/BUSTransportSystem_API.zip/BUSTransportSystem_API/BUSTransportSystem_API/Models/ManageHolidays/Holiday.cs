﻿namespace BUSTransportSystem_API.Models.ManageHolidays
{
    public class Holiday
    {
        public int HolidayID { get; set; }
        public string HolidayName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsSchoolVacation { get; set; }
        public string HolidayType { get; set; }
    }
}
