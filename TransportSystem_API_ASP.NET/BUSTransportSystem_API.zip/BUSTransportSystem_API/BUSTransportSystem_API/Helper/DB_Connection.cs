﻿using System;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;


namespace BUSTransportSystem_API.Helper
{
    public class DB_Connection
    {
        private readonly string _connectionString;

        public DB_Connection(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("BusTransportSystem");
            var connectionStringsSection = configuration.GetSection("ConnectionStrings");
            //Console.WriteLine("Connection Strings:");
            //foreach (var item in connectionStringsSection.GetChildren())
            //{
            //    Console.WriteLine($"{item.Key}: {item.Value}");
            //}

            // Check if the connection string is found
            if (string.IsNullOrEmpty(_connectionString))
            {
                throw new InvalidOperationException("Connection string 'BusTransportSystem' is not found.");
            }
        }

        public SqlConnection GetConnection()
        {
            var connection = new SqlConnection(_connectionString);
            Console.WriteLine($"Connection String: {_connectionString}");
            connection.Open(); // Ensure the connection is explicitly opened here
            return connection;
        }
    }
}
