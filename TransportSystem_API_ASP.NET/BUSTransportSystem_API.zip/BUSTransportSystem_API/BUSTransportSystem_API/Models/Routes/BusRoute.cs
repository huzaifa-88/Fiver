﻿using BUSTransportSystem_API.Models.Stops;

namespace BUSTransportSystem_API.Models.Routes
{
    public class BusRoute
    {
        public int RouteID { get; set; }
        public string RouteName { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidUntil { get; set; }
        public string DailyValidity { get; set; }
        public List<RouteStop> Stops { get; set; }


        //public int RouteID { get; set; }
        //public string RouteNumber { get; set; }
        //public DateTime ValidFrom { get; set; }
        //public DateTime ValidTo { get; set; }
        //public string DailyValidity { get; set; }
        //public int StartStopID { get; set; }        // Start stop ID
        //public int EndStopID { get; set; }          // End stop ID
        //public Stop StartStop { get; set; }         // Start stop object
        //public Stop EndStop { get; set; }           // End stop object
        //public List<RouteStop> Stops { get; set; }  // List of stops in the route
    }

}
