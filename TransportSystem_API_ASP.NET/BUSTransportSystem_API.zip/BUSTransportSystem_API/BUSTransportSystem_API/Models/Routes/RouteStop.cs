﻿namespace BUSTransportSystem_API.Models.Routes
{
    public class RouteStop
    {
        public string RouteName { get; set; }
        public string StopName { get; set; }
        public int Sequence { get; set; }
        public TimeSpan DepartureTime { get; set; }

        //public int RouteStopID { get; set; }
        //public int RouteID { get; set; }
        //public int StopID { get; set; }
        //public int SequenceNumber { get; set; }
        //public TimeSpan ScheduledDepartureTime { get; set; }
    }

}
