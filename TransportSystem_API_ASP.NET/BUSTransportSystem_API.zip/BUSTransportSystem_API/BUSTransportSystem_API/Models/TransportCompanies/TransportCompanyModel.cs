﻿namespace BUSTransportSystem_API.Models.TransportCompanies
{
    public class TransportCompanyModel
    {
        public class TransportCompany
        {
            public int CompanyID { get; set; }
            public string CompanyName { get; set; }
            public string ContactEmail { get; set; }
            public string PhoneNumber { get; set; }
            public string Password { get; set; }
            public DateTime RegisteredDate { get; set; }

        }
    }
}
