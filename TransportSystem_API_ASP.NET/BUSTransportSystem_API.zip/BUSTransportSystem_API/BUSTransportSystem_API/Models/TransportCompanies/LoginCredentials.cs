﻿namespace BUSTransportSystem_API.Models.TransportCompanies
{
    public class LoginCredentials
    {
        public string ContactEmail { get; set; }
        public string Password { get; set; }
    }

}
