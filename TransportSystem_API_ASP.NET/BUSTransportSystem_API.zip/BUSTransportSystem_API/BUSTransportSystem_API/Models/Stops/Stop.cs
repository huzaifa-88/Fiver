﻿namespace BUSTransportSystem_API.Models.Stops
{
    public class Stop
    {
        public int StopID { get; set; }
        public string StopName { get; set; }
        public string ShortDesignation { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }
}
