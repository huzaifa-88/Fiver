﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using BUSTransportSystem_API.Helper;

namespace BUSTransportSystem_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly DB_Connection _dbConnection;

        public TestController(DB_Connection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            // Open connection, perform tasks, and close connection in a controlled manner
            using (var connection = _dbConnection.GetConnection())
            {
                try
                {
                    // Perform database tasks
                    string query = "SELECT * FROM TransportCompanies";
                    using (var command = new SqlCommand(query, connection))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            var transportCompanies = new List<Dictionary<string, object>>();

                            while (reader.Read())
                            {
                                var row = new Dictionary<string, object>();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    row[reader.GetName(i)] = reader.GetValue(i);
                                }
                                transportCompanies.Add(row);
                            }

                            return Ok(transportCompanies); // Return the result as JSON
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    // Handle SQL-specific exceptions
                    return StatusCode(500, $"SQL Error: {sqlEx.Message}");
                }
                catch (Exception ex)
                {
                    // Handle general exceptions
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
                finally
                {
                    // Ensure the connection is closed
                    if (connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }

        //public IActionResult TestConnection()
        //{
        //    // Open connection, perform tasks, and close connection in a controlled manner
        //    using (var connection = _dbConnection.GetConnection())
        //    {
        //        try
        //        {
        //            connection.Open(); // Open the connection

        //            // Perform database tasks
        //            string query = "SELECT * FROM TransportCompanies";
        //            using (var command = new SqlCommand(query, connection))
        //            {
        //                using (var reader = command.ExecuteReader())
        //                {
        //                    var buses = new List<Dictionary<string, object>>();

        //                    while (reader.Read())
        //                    {
        //                        var row = new Dictionary<string, object>();
        //                        for (int i = 0; i < reader.FieldCount; i++)
        //                        {
        //                            row[reader.GetName(i)] = reader.GetValue(i);
        //                        }
        //                        buses.Add(row);
        //                    }

        //                    return Ok(buses); // Return the result
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            // Handle exceptions
        //            return StatusCode(500, $"Internal server error: {ex.Message}");
        //        }
        //        finally
        //        {
        //            if (connection.State == ConnectionState.Open)
        //            {
        //                connection.Close(); // Ensure the connection is closed
        //            }
        //        }
        //    }
        //}
    }
}



//using Microsoft.AspNetCore.Mvc;
//using BUSTransportSystem_API.Helper;
//using System.Data;

//namespace BUSTransportSystem_API.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class TestController : ControllerBase
//    {
//        private readonly DB_Connection dbConnection;

//        public TestController(DB_Connection dbConnection)
//        {
//            this.dbConnection = dbConnection;
//        }
//        [HttpGet("test-connection")]
//        public IActionResult TestConnection()
//        {
//            try
//            {
//                using (var connection = dbConnection.GetConnection())
//                {
//                    if (connection.State == ConnectionState.Open)
//                    {
//                        return Ok("Database connection successful!");
//                    }
//                }
//                return BadRequest("Failed to connect to the database.");
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Internal server error: {ex.Message}");
//            }
//        }
//    }
//}
