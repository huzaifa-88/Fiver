﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using static BUSTransportSystem_API.Models.TransportCompanies.TransportCompanyModel;
using Microsoft.AspNetCore.Identity.Data;
using System.Text.Json;
using BUSTransportSystem_API.Models.TransportCompanies;
using BUSTransportSystem_API.DAL.TransportCompanyDAL;

namespace BUSTransportSystem_API.Controllers.TransportCompany_Con
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransportCompanyController : ControllerBase
    {
        private readonly TransportCompanyDAO _dao;

        public TransportCompanyController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new TransportCompanyDAO(connectionString);
        }

        [HttpPost("register")]
        public IActionResult RegisterTransportCompany([FromBody] TransportCompany company)
        {
            try
            {
                var newId = _dao.AddTransportCompany(company);
                return Ok(new { CompanyID = newId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("get-all")]
        public IActionResult GetAllTransportCompanies()
        {
            try
            {
                var companies = _dao.GetTransportCompanies();
                return Ok(companies);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("login")]
        public IActionResult LoginTransportCompany([FromBody] LoginCredentials credentials)
        {
            try
            {
                if (string.IsNullOrEmpty(credentials.ContactEmail) || string.IsNullOrEmpty(credentials.Password))
                {
                    return BadRequest("Email and password are required.");
                }

                bool isValid = _dao.VerifyLoginCredentials(credentials.ContactEmail, credentials.Password);

                if (isValid)
                {
                    return Ok(new { Message = "Login successful" });
                }
                else
                {
                    return Unauthorized(new { Message = "Invalid email or password" });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
