﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using BUSTransportSystem_API.Models;
using BUSTransportSystem_API.DAL;
using BUSTransportSystem_API.Models.ManageHolidays;

namespace BUSTransportSystem_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HolidayController : ControllerBase
    {
        private readonly HolidayDAO _dao;

        public HolidayController(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("BusTransportSystem");
            _dao = new HolidayDAO(connectionString);
        }

        // Add a new holiday
        [HttpPost("add")]
        public IActionResult AddHoliday([FromBody] Holiday holiday)
        {
            try
            {
                if (holiday == null || string.IsNullOrEmpty(holiday.HolidayName))
                {
                    return BadRequest("Holiday name, start date, end date, and school vacation flag are required.");
                }

                var newHolidayID = _dao.AddHoliday(holiday);
                return Ok(new { HolidayID = newHolidayID });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Get all holidays
        [HttpGet("get-all")]
        public IActionResult GetAllHolidays()
        {
            try
            {
                var holidays = _dao.GetAllHolidays();
                return Ok(holidays);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Update an existing holiday
        [HttpPut("update")]
        public IActionResult UpdateHoliday([FromBody] Holiday holiday)
        {
            try
            {
                if (holiday == null)
                {
                    return BadRequest("Holiday details are required.");
                }

                // Check if the Holiday exists by name and type
                var existingHoliday = _dao.GetHolidayByNameAndType(holiday.HolidayName, holiday.HolidayType);

                if (existingHoliday == null)
                {
                    return NotFound(new { Message = "Holiday with the given name and type not found." });
                }

                // If holiday is found, proceed with the update
                _dao.UpdateHoliday(holiday);

                return Ok(new { Message = "Holiday updated successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        //public IActionResult UpdateHoliday([FromBody] Holiday holiday)
        //{
        //    try
        //    {
        //        if (holiday == null)
        //        {
        //            return BadRequest("Holiday details are required.");
        //        }

        //        _dao.UpdateHoliday(holiday);
        //        return Ok(new { Message = "Holiday updated successfully." });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"Internal server error: {ex.Message}");
        //    }
        //}

        // Delete a holiday
        //[HttpDelete("delete/{holidayName}")]
        [HttpDelete("delete")]
        public IActionResult DeleteHoliday([FromQuery] string holidayName)
        {
            try
            {
                if (string.IsNullOrEmpty(holidayName))
                {
                    return BadRequest("Holiday name is required.");
                }

                _dao.DeleteHolidayByName(holidayName);
                return Ok(new { Message = "Holiday deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
