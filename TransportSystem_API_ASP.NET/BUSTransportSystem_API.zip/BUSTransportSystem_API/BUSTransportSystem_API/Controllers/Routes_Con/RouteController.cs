﻿using BUSTransportSystem_API.DAL.RoutesDAL;
using BUSTransportSystem_API.Models.Routes;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Routes_Con
{
    [ApiController]
    [Route("api/routes")]
    public class RouteController : ControllerBase
    {
        private readonly RouteDAO _dao;

        public RouteController(RouteDAO dao)
        {
            _dao = dao;
        }

        [HttpPost("createRoute")]
        public IActionResult CreateRoute([FromBody] BusRoute route)
        {
            try
            {
                if (string.IsNullOrEmpty(route.RouteName))
                {
                    return BadRequest("Route name is required.");
                }

                // Insert the new route into the database
                var newRouteID = _dao.AddRoute(route);

                return Ok(new { Message = "Route created successfully.", RouteID = newRouteID });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }

}
