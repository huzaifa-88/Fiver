﻿using BUSTransportSystem_API.DAL.RoutesDAL;
using BUSTransportSystem_API.Models.Routes;
using Microsoft.AspNetCore.Mvc;

namespace BUSTransportSystem_API.Controllers.Routes_Con
{
    [ApiController]
    [Route("api/routesStop")]
    public class RouteStopController : ControllerBase
    {
        private readonly RouteStopDAO _dao;

        public RouteStopController(RouteStopDAO dao)
        {
            _dao = dao;
        }

        [HttpPost("addStopToRoute")]
        public IActionResult AddStopToRoute([FromBody] RouteStop request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.RouteName) || string.IsNullOrEmpty(request.StopName))
                {
                    return BadRequest("Route name and stop name are required.");
                }

                // Retrieve RouteID and StopID based on RouteName and StopName
                var routeID = _dao.GetRouteIDByName(request.RouteName);
                var stopID = _dao.GetStopIDByName(request.StopName);

                if (routeID == null || stopID == null)
                {
                    return NotFound("Route or Stop does not exist.");
                }

                // Add stop to the route in the RouteStops table
                var result = _dao.AddStopToRoute(routeID.Value, stopID.Value, request.Sequence, request.DepartureTime);

                if (!result)
                {
                    return BadRequest("Failed to add stop to the route.");
                }

                return Ok(new { Message = "Stop added to the route successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
