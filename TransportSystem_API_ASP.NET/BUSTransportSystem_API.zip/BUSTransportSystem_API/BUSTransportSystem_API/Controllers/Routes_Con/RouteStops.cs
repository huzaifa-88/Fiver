﻿namespace BUSTransportSystem_API.Controllers.Routes_Con
{
    public class RouteStops
    {
    }
}
