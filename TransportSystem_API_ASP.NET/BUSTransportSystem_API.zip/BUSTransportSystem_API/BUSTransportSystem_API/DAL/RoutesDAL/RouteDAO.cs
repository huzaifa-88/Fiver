﻿using Microsoft.Data.SqlClient;
using BUSTransportSystem_API.Models.Routes;
using BUSTransportSystem_API.Models.Stops;

namespace BUSTransportSystem_API.DAL.RoutesDAL
{
    public class RouteDAO
    {
        private readonly string _connectionString;

        public RouteDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Method to add a new route
        public int AddRoute(BusRoute route)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var query = "INSERT INTO Routes (RouteName, ValidFrom, ValidTo, DailyValidity) OUTPUT INSERTED.RouteID VALUES (@RouteName, @ValidFrom, @ValidTo, @DailyValidity)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RouteName", route.RouteName);
                    command.Parameters.AddWithValue("@ValidFrom", route.ValidFrom);
                    command.Parameters.AddWithValue("@ValidTo", route.ValidUntil);
                    command.Parameters.AddWithValue("@DailyValidity", route.DailyValidity);

                    var result = command.ExecuteScalar();
                    return Convert.ToInt32(result);
                }
            }
        }


        public int? GetStopIDByName(string stopName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT StopID FROM Stops WHERE StopName = @StopName";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StopName", stopName);
                    var result = command.ExecuteScalar();
                    return result != null ? (int?)result : null;
                }
            }
        }

        public int? GetRouteIDByName(string routeName)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT RouteID FROM Routes WHERE RouteName = @RouteName";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@RouteName", routeName);
                    var result = command.ExecuteScalar();
                    return result != null ? (int?)result : null;
                }
            }
        }

        //public int AddRoute(BusRoute route)
        //{
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        using (var transaction = connection.BeginTransaction())
        //        {
        //            try
        //            {
        //                // Insert route with Start and End Stop
        //                var query = "INSERT INTO Routes (RouteNumber, ValidFrom, ValidTo, DailyValidity, StartStopID, EndStopID) " +
        //                            "OUTPUT INSERTED.RouteID VALUES (@RouteNumber, @ValidFrom, @ValidTo, @DailyValidity, @StartStopID, @EndStopID)";
        //                int routeId;

        //                using (var command = new SqlCommand(query, connection, transaction))
        //                {
        //                    command.Parameters.AddWithValue("@RouteNumber", route.RouteNumber);
        //                    command.Parameters.AddWithValue("@ValidFrom", route.ValidFrom);
        //                    command.Parameters.AddWithValue("@ValidTo", route.ValidTo);
        //                    command.Parameters.AddWithValue("@DailyValidity", route.DailyValidity);
        //                    command.Parameters.AddWithValue("@StartStopID", route.StartStopID);
        //                    command.Parameters.AddWithValue("@EndStopID", route.EndStopID);

        //                    routeId = (int)command.ExecuteScalar();
        //                }

        //                // Insert route stops
        //                foreach (var stop in route.Stops)
        //                {
        //                    var stopQuery = "INSERT INTO RouteStops (RouteID, StopID, SequenceNumber, ScheduledDepartureTime) " +
        //                                    "VALUES (@RouteID, @StopID, @SequenceNumber, @ScheduledDepartureTime)";
        //                    using (var stopCommand = new SqlCommand(stopQuery, connection, transaction))
        //                    {
        //                        stopCommand.Parameters.AddWithValue("@RouteID", routeId);
        //                        stopCommand.Parameters.AddWithValue("@StopID", stop.StopID);
        //                        stopCommand.Parameters.AddWithValue("@SequenceNumber", stop.SequenceNumber);
        //                        stopCommand.Parameters.AddWithValue("@ScheduledDepartureTime", stop.ScheduledDepartureTime);

        //                        stopCommand.ExecuteNonQuery();
        //                    }
        //                }

        //                transaction.Commit();
        //                return routeId;
        //            }
        //            catch
        //            {
        //                transaction.Rollback();
        //                throw;
        //            }
        //        }
        //    }
        //}
    }

}
