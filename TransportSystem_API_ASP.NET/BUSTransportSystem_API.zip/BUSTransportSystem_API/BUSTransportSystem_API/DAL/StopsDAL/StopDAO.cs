﻿using System;
using Microsoft.Data.SqlClient;
using BUSTransportSystem_API.Models.Stops;

namespace BusTransportSystem_API.DAL
{
    public class StopDAO
    {
        private readonly string _connectionString;

        public StopDAO(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Add new stop
        public int AddStop(Stop stop)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "INSERT INTO Stops (StopName, ShortDesignation, Latitude, Longitude) " +
                            "VALUES (@StopName, @ShortDesignation, @Latitude, @Longitude);" +
                            "SELECT SCOPE_IDENTITY();";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StopName", stop.StopName);
                    command.Parameters.AddWithValue("@ShortDesignation", stop.ShortDesignation);
                    command.Parameters.AddWithValue("@Latitude", stop.Latitude);
                    command.Parameters.AddWithValue("@Longitude", stop.Longitude);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        // Edit existing stop
        public void UpdateStop(Stop stop)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "UPDATE Stops SET StopName = @StopName, Latitude = @Latitude, Longitude = @Longitude " +
                            "WHERE ShortDesignation = @ShortDesignation";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StopName", stop.StopName);
                    command.Parameters.AddWithValue("@Latitude", stop.Latitude);
                    command.Parameters.AddWithValue("@Longitude", stop.Longitude);
                    command.Parameters.AddWithValue("@ShortDesignation", stop.ShortDesignation);

                    command.ExecuteNonQuery();
                }
            }
        }

        public Stop GetStopByShortDesignation(string shortDesignation)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var query = "SELECT * FROM Stops WHERE ShortDesignation = @ShortDesignation";

                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ShortDesignation", shortDesignation);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Stop
                            {
                                StopID = reader.GetInt32(0),
                                StopName = reader.GetString(1),
                                ShortDesignation = reader.GetString(2),
                                Latitude = reader.GetDecimal(3),
                                Longitude = reader.GetDecimal(4)
                            };
                        }
                    }
                }
            }
            return null; // Return null if the stop is not found
        }

    }
}
